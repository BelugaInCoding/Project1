create
    definer = root@localhost procedure del_data()
BEGIN
    DELETE FROM wrongquestions WHERE frequency<1;
END;

