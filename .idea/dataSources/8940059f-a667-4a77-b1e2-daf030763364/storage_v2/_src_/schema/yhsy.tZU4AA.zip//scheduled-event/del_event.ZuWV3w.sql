create definer = root@localhost event del_event on schedule
    every '1' DAY
        starts '2020-03-19 00:00:00'
    enable
    do
    call del_data();

